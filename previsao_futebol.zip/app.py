from flask import Flask, jsonify
from flask_cors import CORS

app = Flask(__name__)
CORS(app)  # Permite chamadas do frontend

@app.route("/api/predictions", methods=["GET"])
def get_predictions():
    # Dados simulados – futuramente conectaremos com IA real
    dados = [
        {
            "jogo": "Real Madrid x Barcelona",
            "horario": "15:30",
            "previsao_gol": "37, 58, 81 min",
            "previsao_escanteio": "22, 45, 67 min"
        },
        {
            "jogo": "Liverpool x Arsenal",
            "horario": "16:00",
            "previsao_gol": "19, 42, 78 min",
            "previsao_escanteio": "12, 33, 59 min"
        }
    ]
    return jsonify(dados)

if __name__ == "__main__":
    app.run(debug=True, host="0.0.0.0", port=5000)
